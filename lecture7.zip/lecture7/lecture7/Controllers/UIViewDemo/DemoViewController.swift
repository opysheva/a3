//
//  DemoViewController.swift
//  lecture7
//
//  Created by admin on 01.02.2021.
//

import UIKit

class DemoViewController: UIViewController {

 
    @IBOutlet weak var firstView: UIView!
    
    @IBOutlet weak var secondView: UIView!
  
    @IBOutlet weak var segmentControlButton: UISegmentedControl!
    
    @IBOutlet weak var cellectionView: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isHidden = true
    }
    
    @IBOutlet weak var Image: UIImageView!
    
  
    @IBOutlet weak var TitleV: UILabel!
    @IBOutlet weak var Description: UILabel!
    @IBOutlet weak var Price: UILabel!
    
    
    @IBAction func AddCart(_ sender: Any) {
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        firstView.isHidden = false
        secondView.isHidden = true
        
    }
    
    
    @IBAction func changeLayout(_ sender: UISegmentedControl) {
        if secondView.isHidden{
            firstView.isHidden = true
            secondView.isHidden = false
        }
        else{
            firstView.isHidden = false
            secondView.isHidden = true
        }
}
}
